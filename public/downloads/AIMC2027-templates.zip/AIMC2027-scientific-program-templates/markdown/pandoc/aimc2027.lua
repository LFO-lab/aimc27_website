--[[
Pandoc Lua filter for the AIMC 2027 Markdown template (LaTeX/PDF output).

1. Tables become floating `table` environments with a booktabs `tabular`
   and the caption ABOVE the table (pandoc's default `longtable` does not
   work in a two-column layout).
2. Figures and tables with the class `.wide` span both columns
   (`figure*` / `table*`), like LaTeX's starred environments.
3. A fenced div with the class `center` becomes a `center` environment.
]]

local function latex(blocks)
  return pandoc.write(pandoc.Pandoc(blocks), 'latex'):gsub('%s+$', '')
end

local function inl(inlines)
  return latex({ pandoc.Plain(inlines) })
end

local function cell_text(cell)
  return latex(cell.contents):gsub('\n\n', ' \\newline ')
end

local align_map = {
  AlignLeft = 'l', AlignRight = 'r', AlignCenter = 'c', AlignDefault = 'l'
}

local function has_class(el, cls)
  for _, c in ipairs(el.classes or el.attr.classes) do
    if c == cls then return true end
  end
  return false
end

local function row_latex(row)
  local cells = {}
  for _, cell in ipairs(row.cells) do
    local txt = cell_text(cell)
    if cell.col_span and cell.col_span > 1 then
      txt = string.format('\\multicolumn{%d}{c}{%s}', cell.col_span, txt)
    end
    table.insert(cells, txt)
  end
  return table.concat(cells, ' & ') .. ' \\\\'
end

function Table(tbl)
  if not FORMAT:match('latex') then return nil end
  local spec = {}
  for _, cs in ipairs(tbl.colspecs) do
    table.insert(spec, align_map[cs[1]] or 'l')
  end
  local env = has_class(tbl, 'wide') and 'table*' or 'table'
  local out = { '\\begin{' .. env .. '}[hbt!]', '\\centering' }
  local cap = tbl.caption and tbl.caption.long or {}
  local ident = tbl.identifier or ''
  if #cap > 0 then
    local captext = latex(cap):gsub('\n\n', ' ')
    -- older pandoc versions leave "{#tab:id}" inside the caption text
    local plain = pandoc.utils.stringify(cap)
    local found = plain:match('{#([^}]+)}%s*$')
    if found then
      if ident == '' then ident = found end
      captext = captext:gsub('%s*\\{\\#.-\\}%s*$', '')
    end
    table.insert(out, '\\caption{' .. captext .. '}')
  end
  if ident ~= '' then
    table.insert(out, '\\label{' .. ident .. '}')
  end
  table.insert(out, '\\begin{tabular}{' .. table.concat(spec) .. '}')
  table.insert(out, '\\toprule')
  local nhead = #tbl.head.rows
  for i, row in ipairs(tbl.head.rows) do
    table.insert(out, row_latex(row))
    -- short rule under header cells that span several columns (like "Part")
    if i < nhead then
      local col = 1
      for _, cell in ipairs(row.cells) do
        local span = cell.col_span or 1
        if span > 1 and #cell.contents > 0 then
          table.insert(out, string.format('\\cmidrule(r){%d-%d}', col, col + span - 1))
        end
        col = col + span
      end
    end
  end
  if #tbl.head.rows > 0 then table.insert(out, '\\midrule') end
  for _, body in ipairs(tbl.bodies) do
    for _, row in ipairs(body.body) do
      table.insert(out, row_latex(row))
    end
  end
  table.insert(out, '\\bottomrule')
  table.insert(out, '\\end{tabular}')
  table.insert(out, '\\end{' .. env .. '}')
  return pandoc.RawBlock('latex', table.concat(out, '\n'))
end

function Figure(fig)
  if not FORMAT:match('latex') then return nil end
  local wide = has_class(fig, 'wide')
  -- in pandoc 3 the classes written after an image stay on the image
  pandoc.walk_block(fig, { Image = function(img)
    if has_class(img, 'wide') then wide = true end
  end })
  if not wide then return nil end
  local tex = latex({ fig })
  tex = tex:gsub('\\begin{figure}', '\\begin{figure*}', 1)
           :gsub('\\end{figure}', '\\end{figure*}', 1)
  return pandoc.RawBlock('latex', tex)
end

-- 3. A fenced div with the class `center` (::: center ... :::) becomes a
--    LaTeX `center` environment, e.g. for a centered link.
function Div(div)
  if not FORMAT:match('latex') then return nil end
  if not has_class(div, 'center') then return nil end
  local out = { pandoc.RawBlock('latex', '\\begin{center}') }
  for _, b in ipairs(div.content) do table.insert(out, b) end
  table.insert(out, pandoc.RawBlock('latex', '\\end{center}'))
  return out
end
