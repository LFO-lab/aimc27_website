#!/bin/sh
# Same as "make": builds aimc2027.pdf from aimc2027.md.
# Needs pandoc (3.x) and a LaTeX distribution (pdflatex, biber, latexmk,
# biblatex, biblatex-apa).
set -e
cd "$(dirname "$0")"
pandoc aimc2027.md --biblatex --lua-filter=pandoc/aimc2027.lua \
  --template=pandoc/aimc2027.latex -o aimc2027.tex
latexmk -pdf -interaction=nonstopmode aimc2027.tex
echo "Done: aimc2027.pdf"
